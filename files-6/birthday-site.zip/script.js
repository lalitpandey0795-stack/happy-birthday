const noButton = document.getElementById("noButton");
const yesButton = document.getElementById("yesButton");
const openingScreen = document.querySelector(".opening-screen");
const transitionScreen = document.getElementById("transitionScreen");
const birthdaySection = document.querySelector(".birthday-section");
const poemButton = document.getElementById("poemButton");
const poemSection = document.getElementById("poemSection");
const backButton = document.getElementById("backButton");

/* The NO button escapes */

function moveNoButton() {

    const buttonWidth = noButton.offsetWidth;
    const buttonHeight = noButton.offsetHeight;

    const maxX = window.innerWidth - buttonWidth - 20;
    const maxY = window.innerHeight - buttonHeight - 20;

    const randomX = Math.max(20, Math.random() * maxX);
    const randomY = Math.max(20, Math.random() * maxY);

    noButton.style.position = "fixed";
    noButton.style.left = randomX + "px";
    noButton.style.top = randomY + "px";

    const messages = [
        "Nice try 😭",
        "NOPE 💀",
        "Not happening!",
        "Try again 👀",
        "You can't escape this question!",
        "Vivian... really? 😭",
        "Wrong answer 💗"
    ];

    const randomMessage =
        messages[Math.floor(Math.random() * messages.length)];

    noButton.textContent = randomMessage;
}

/* Desktop: escape when the mouse gets close */
noButton.addEventListener("mouseenter", moveNoButton);

/* Mobile: escape when she touches the button */
noButton.addEventListener("touchstart", function (event) {
    event.preventDefault();
    moveNoButton();
});

/* YES button: opening -> transition -> birthday */
yesButton.addEventListener("click", () => {
    openingScreen.style.display = "none";
    transitionScreen.style.display = "flex";

    setTimeout(() => {
        transitionScreen.style.display = "none";
        birthdaySection.style.display = "block";
        birthdaySection.classList.add("reveal");
        window.scrollTo(0, 0);
    }, 2500);
});

/* NEXT button: reveal the poem and scroll to it */
poemButton.addEventListener("click", () => {
    poemSection.style.display = "block";
    poemSection.classList.add("reveal");

    requestAnimationFrame(() => {
        poemSection.scrollIntoView({ behavior: "smooth", block: "start" });
    });
});

/* Back button: return to the birthday message */
backButton.addEventListener("click", () => {
    birthdaySection.scrollIntoView({ behavior: "smooth", block: "start" });
});

/* POEM -> PAGE 4 (letter) */
const letterButton = document.getElementById("letterButton");
const letterSection = document.getElementById("letterSection");

letterButton.addEventListener("click", () => {
    letterSection.style.display = "block";
    letterSection.classList.add("reveal");

    requestAnimationFrame(() => {
        letterSection.scrollIntoView({ behavior: "smooth", block: "start" });
    });
});

/* PAGE 4 -> PAGE 5 (final celebration) */
const finalButton = document.getElementById("finalButton");
const finalSection = document.getElementById("finalSection");

finalButton.addEventListener("click", () => {
    finalSection.style.display = "block";
    finalSection.classList.add("reveal");

    requestAnimationFrame(() => {
        finalSection.scrollIntoView({ behavior: "smooth", block: "start" });
    });
});

/* (Page 5 logic lives in birthday.html / index.html) */
